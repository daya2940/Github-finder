# Memory Game Project
download or clone from udacity's github repo
open index.html and observe the static html page
To get started, open `js/app.js` and start building out the app's functionality
it's per your discreation to use predefined css or you can define your own
the job here is to make it dynamic to do that follow the steps in the code(app.js)

>>dependencies used here are
>>https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css
>>https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/
>>https://fonts.googleapis.com/css?family=Coda

## Features
- Count your moves
- Live Stopwatch
- Rating System [ Based on your **Moves!** ]
- Retry/Restart the game button

## How to Play?
- Click on any card and you will see an image
- Keep searching for this image's peer in other cards
- When you find the right one, both of them will stay flipped
- If you didn't find it, both of them will be darkened  again

> Try to find the pairs in as less moves as possible to get a better rate!
>> contribute here https://codepen.io/sau3681/pen/yqzEMP


